<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/e-ticketingAirplane/assets/style/sidebar.css">
    <link rel="stylesheet" href="/e-ticketingAirplane/assets/sweet-alert/css/bootstrap.min.css">
    <link rel="stylesheet" href="/e-ticketingAirplane/assets/sweet-alert/css/sweetalert.css">

    <title>Sidebar Admin</title>
</head>
<style>
    body {
        display: flex;
        height: 100vh;
        margin: 0;
        background-color: white;
    }

    .sidebar-admin {
        width: 200px;
        background-color:  #5D0E41;
        color: #fff;
        padding: 30px;
        border-radius: 5px;
        height: 700px;
    }

    .sidebar-admin a {
        display: block;
        color: #fff;
        text-decoration: none;
        padding: 10px;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .sidebar-admin a:hover {
        background-color: black;
    }

    .sidebar-admin a.active {
        background-color: black;
    }
</style>

<body>
    <div class="sidebar-admin">      
        <a href="/e-ticketingAirplane/petugas/index.php" class="<?php if($page == "Dashboard") echo"active" ?>"> Dashboard</a><br><br>
        <a href="/e-ticketingAirplane/petugas/pengguna/" class="<?php if($page == "pengguna") echo"active" ?>">Data Pengguna</a><br><br>&nbsp;&nbsp;
        <a href="/e-ticketingAirplane/petugas/maskapai/" class="<?php if($page == "maskapai") echo"active" ?>">Data Maskapai</a><br><br>&nbsp;&nbsp;
        <a href="/e-ticketingAirplane/petugas/kota" class="<?php if($page == "kota") echo"active" ?>">Data Kota</a><br><br>&nbsp;&nbsp;
        <a href="/e-ticketingAirplane/petugas/rute" class="<?php if($page == "rute") echo"active" ?>"> Data Rute</a><br><br>&nbsp;&nbsp;
        <a href="/e-ticketingAirplane/petugas/jadwal" class="<?php if($page == "penerbangan") echo"active" ?>"> Jadwal Penerbangan</a><br><br>&nbsp;&nbsp;
        <a href="/e-ticketingAirplane/logout.php"
            onClick="return confirm('Apakah anda yakin ingin logout?')">Logout</a>
    </div>

    <script src="/e-ticketingAirplane/sweet-alert/js/jquery-2.1.4.min.js"></script>
    <script src="/e-ticketingAirplane/sweet-alert/js/sweetalert.min.js"></script>
</body>

</html>