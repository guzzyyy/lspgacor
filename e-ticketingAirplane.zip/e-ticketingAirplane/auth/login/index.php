<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="/lsp_pesawat/auth/login/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
body {
    font-family: sans-serif;
}

.login {
    background: #5356FF;
    box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.25);
    padding: 20px;
    height: 580px;
    border-radius: 10px;
    margin-top: 80px;
    margin-bottom: 20px;
}

.page-login .content h3,
.page-login .content .h3 {
    margin-top: 30px;
    font-size: 21px;
    width: 95%;
    margin-left: 30px;
    font-weight: 600;
    color: #141b21;
}

.page-login p {
    margin-left: 30px;
}

.page-login .card-login {
    padding: 15px 18px 20px;
    border-radius: 12px;
    background: #ffffff;
    border: none;
    margin-bottom: 20px;
    margin-top: 20px;
}

.page-login .card-login .form-control {
    background: #f7f7f7;
    border: 1px solid #bac6f2;
    -webkit-box-sizing: border-box;
    box-sizing: border-box;
    border-radius: 12px;
}

.page-login .card-login .btn-login {
    color: black;
    background: #41C9E2;
    border: none;
    margin-top: 15px;
    padding: 8px;
    border-radius: 12px;
    font-weight: 500;
    width: 100%;
}

.page-login .card-login .text-user {
    margin-top: 15px;
}

.page-login .card-login .text-user a {
    text-decoration: none;
    color: #ff0090 ;
    font-size: 14px;
    font-weight: 300;
}


    </style>
</head>
<body style="background: #ECF5DA;">
<div class="container">
        <div class="login">
            <div class="row justify-content-center align-items-center">
                <div class="col-6">
                    <div class="page-login">
                        <div class="col-10">
                            <div class="content">
                                <h3>E-Ticketing Airplane</h3>
                                <p>Login your account</p>
                            </div>
                                <div class="card card-login p-4">
                                    <form action="process.php" method="POST">
                                        <label class="form-label">Username</label>
                                        <input type="text" name="username" id="" class="form-control mb-3" />
                                        <label class="form-label">Password</label>
                                        <input type="password" name="password" id="" class="form-control mb-2" />
                                        <button class="btn btn-login" type="submit" name="login">Login</button>
                                    </div>
                                </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <!-- <img src="/e-ticketing/assets/images/bandara-terindah.jpg" class="card-img-top" alt="..."> -->
            </div>
        </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>